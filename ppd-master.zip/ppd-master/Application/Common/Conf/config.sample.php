<?php
return array(
	//'配置项'=>'配置值'
    //数据库配置
    'DB_TYPE'   =>  'mysql',
    'DB_HOST'   =>  'localhost',
    'DB_USER'   =>  'root',
    // 'DB_PWD'    =>  '',
    'DB_PWD'    =>  'ppd1234!@#',
    'DB_NAME'   =>  'ppd',
    'DB_PREFIX' =>  'tp_',
);
